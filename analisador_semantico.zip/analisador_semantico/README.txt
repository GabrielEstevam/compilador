How to compile on Windows:
g++ lex.cpp sin.cpp sem.cpp main.cpp -o compiler

How to execute on Windows:
compiler exemplos/code1.txt
compiler exemplos/code2.txt
compiler exemplos/code3.txt