How to compile on Windows:
g++ lex.cpp main.cpp -o compiler

How to execute on Windows:
compiler arquivo.txt